﻿define("epi-ecf-ui/widget/viewmodel/DiscountTreeStoreModel", [
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Stateful",
    "dojo/when",
// epi
   "epi/dependency",
   "epi/shell/TypeDescriptorManager",
// epi-cms
    "epi-cms/core/ContentReference",
// dijit
    "dijit/Destroyable",
// resources
   "epi/i18n!epi/nls/commerce.widget.marketingtoolbar"
], function (
    array,
    declare, 
    lang,
    Stateful,
    when,
// epi
   dependency,
   TypeDescriptorManager,
// epi-cms
    ContentReference,
// dijit
    Destroyable,
// resources
   sharedResources
) {

    return declare([Stateful, Destroyable], {
        // summary:
        //      Represents the store model for DiscountTree
        //
        // tags:
        //      internal
        
        // store: [protected] dojo.store.api.Store
        //      Underlying store that will be queried for tree items.
        store: null,

        // root: [protected]
        //      The root content link.
        root: undefined,

        // excludedLink: [public] String
        //      Content reference of the excluded discount.
        excludedLink: null,

        // checkedItems: [public] ContentLink Array
        //      List of checked content links.
        checkedItems: null,

        constructor: function (args) {
            lang.mixin(this, args);

            if (!this.store) {
                var registry = dependency.resolve("epi.storeregistry");
                this.store = registry.get("epi.cms.content.light");
            }
        },

        _excludedLinkSetter: function (value) {
            if (ContentReference.compareIgnoreVersion(this.excludedLink, value)) {
                return;
            }

            // enable the old one and disable the new one
            if (this.excludedLink) {
                this._updateContentDisableState(this.excludedLink, false);
            }

            this.excludedLink = value;
            this._updateContentDisableState(this.excludedLink, true);
        },

        _updateContentDisableState: function(contentLink, disabled) {
            when(this.store.get(contentLink), lang.hitch(this, function (content) {
                content.disabled = disabled;
                this.onChange(content); // by triggering onChange, the tree will update the node to reflect item's changes.
            }));
        },

        updateContentSelectedState: function(content) {
            content.selected = this._isNodeContentSelected(content);
            this.onChange(content); // by triggering onChange, the tree will update the node to reflect item's changes.
            return content.selected;
        },

        _getQueryOptions: function () {
            return {
                ignore: ["query"],
                comparers: {
                    "typeIdentifiers": lang.hitch(this, function (queryValue, instance) {
                        return array.some(queryValue, lang.hitch(this, function (item) {
                            return item === instance.typeIdentifier || TypeDescriptorManager.isBaseTypeIdentifier(instance.typeIdentifier, item);
                        }));
                    }),
                    "referenceId": function (queryValue, instance) {
                        return ContentReference.compareIgnoreVersion(queryValue, instance.parentLink);
                    }
                }
            };
        },

        getRoot: function (onItem) {
            // summary:
            //      Calls onItem with the root item for the tree, possibly a fabricated item.

            when(this.store.get(this.root), lang.hitch(this, function (item) {
                item.name = sharedResources.allcampaigns;
                item.disabled = false; // root node is always available for selecting
                item.selected = this._isNodeContentSelected(item);
                onItem(item);
            }));
        },

        mayHaveChildren: function (item) {
            // summary:
            //      Tells if an item has or may have children.  Implementing logic here
            //      avoids showing +/- expando icon for nodes that we know don't have children.
            //      (For efficiency reasons we may not want to check if an element actually
            //      has children until user clicks the expando node)

            return item.hasChildren;
        },

        getChildren: function (parentItem, onComplete) {
            // summary:
            //      Calls onComplete() with array of child items of given parent item, all loaded.

            var id = this.getIdentity(parentItem),
                query = { referenceId: id, query: "getchildren" },
                queryOptions = this._getQueryOptions(),
                results = this.store.query(query, queryOptions);

            // Setup listener in case children list changes, or the item(s) in the children list are updated in some way.
            if(results.observe){
                this.own(results.observe(lang.hitch(this, function(obj, removedFrom, insertedInto){
                    this.onChange(obj);

                    when(this.store.query(query, queryOptions), lang.hitch(this, function (children) {

                        var hasChildren = children && children.length > 0;

                        if (parentItem.hasChildren !== hasChildren) {
                            parentItem.hasChildren = hasChildren;
                            this.onChange(parentItem);
                        }

                        this.onChildrenChange(parentItem, children);
                    }));

                    var removingItem = insertedInto === -1;
                    if (!removingItem && this.mayHaveChildren(obj)) {
                        when(this.store.query({ referenceId: obj.contentLink, query: "getchildren" }, queryOptions), lang.hitch(this, function (children) {
                            this.onChildrenChange(obj, children);
                        }));
                    }
                }), true));
            }

            return when(results).then(lang.hitch(this, function (children) {
                array.forEach(children, function (content) {
                    content.disabled = this._isNodeContentDisabled(content, this.excludedLink);
                    content.selected = this._isNodeContentSelected(content);
                }, this);

                parentItem.children = children;
                onComplete(children);
            }));
        },

        _isNodeContentDisabled: function (content, excludedLink) {
            return ContentReference.compareIgnoreVersion(content.contentLink, excludedLink);
        },

        _isNodeContentSelected: function (content) {
            return array.some(this.checkedItems, function (item) {
                return ContentReference.compareIgnoreVersion(content.contentLink, item.contentLink);
            });
        },

        getIdentity: function (item) {
            // summary:
            //      Returns identity for an item

            return this.store.getIdentity(item);
        },

        getLabel: function (item) {
            // summary:
            //      Get the label for an item

            return item.name;
        }
    });
});