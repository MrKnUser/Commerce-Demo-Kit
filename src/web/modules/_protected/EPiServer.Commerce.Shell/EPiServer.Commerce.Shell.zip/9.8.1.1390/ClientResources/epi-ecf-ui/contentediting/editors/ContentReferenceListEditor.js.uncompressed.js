﻿define("epi-ecf-ui/contentediting/editors/ContentReferenceListEditor", [
    // dojo
    "dojo/_base/declare",

    // epi-cms
    "epi-cms/contentediting/editors/ContentReferenceListEditor",

    // epi commerce
    "./model/ContentReferenceListEditorModel"
],
function (
    //dojo
    declare,

    // epi-cms
    BaseContentReferenceListEditor,
    
    // epi commerce
    ContentReferenceListEditorModel
) {
    return declare([BaseContentReferenceListEditor], {
        // summary:
        //      Represents the Content reference list editor in Commerce, which handles the Change context command as opening
        //      the content edit in Edit mode.

        postMixInProperties: function () {
            // summary:
            //      Called after the parameters to the widget have been read-in,
            //      but before the widget template is instantiated.
            // tags:
            //      protected

            this.model = new ContentReferenceListEditorModel();
            this.inherited(arguments);
        }
    });
});