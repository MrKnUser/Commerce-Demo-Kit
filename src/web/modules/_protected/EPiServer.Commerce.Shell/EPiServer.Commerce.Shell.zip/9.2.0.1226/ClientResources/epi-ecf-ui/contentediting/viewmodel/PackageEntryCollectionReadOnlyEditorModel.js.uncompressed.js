﻿define("epi-ecf-ui/contentediting/viewmodel/PackageEntryCollectionReadOnlyEditorModel", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",

    "../ModelSupport",
    "./ReadOnlyCollectionEditorModel"
],
function (
    //dojo
    declare,
    lang,

    ModelSupport,
    ReadOnlyCollectionEditorModel
) {
    return declare([ReadOnlyCollectionEditorModel], {
        // module: 
        //      epi-ecf-ui/contentediting/viewmodel/PackageEntryCollectionReadOnlyEditorModel
        // summary:
        //      Represents the model for PackageEntryCollectionReadOnlyEditor

        _storeKey: "epi.commerce.relation",

        createQuery: function (referenceId) {
            return { referenceId: referenceId, relationTypes: [ModelSupport.relationType.packageEntry] };
        }
    });
});