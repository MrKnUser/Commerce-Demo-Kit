require({cache:{
'url:epi-ecf-ui/widget/templates/CampaignItemList.html':"﻿<div>\n    <!-- the toolbar is only here to be able to resize without exceptions -->\n    <div data-dojo-attach-point=\"toolbar\" data-dojo-type=\"dijit/_WidgetBase\" style=\"display:none\"></div>\n    <div data-dojo-attach-point=\"gridNode\"></div>\n</div>\n"}});
﻿define("epi-ecf-ui/widget/CampaignItemList", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/event",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/dom-class",
    "dojo/keys",
    "dojo/when",
// dijit
    "dijit/_TemplatedMixin",
// epi
    "epi/shell/command/builder/ButtonBuilder",
    "epi/shell/TypeDescriptorManager",
// epi-cms
    "epi-cms/widget/_ConfigurableContentListBase",
// commerce
    "./viewmodel/CampaignItemListModel",
    "../MarketingUtils",
    "dojo/text!./templates/CampaignItemList.html",
// resources
    "epi/i18n!epi/nls/commerce.widget.campaignitemlist"
],
function (
// dojo
    declare,
    event,
    lang,
    aspect,
    domClass,
    keys,
    when,
//dijit
    _TemplatedMixin,
// epi
    ButtonBuilder,
    TypeDescriptorManager,
// epi-cms
    _ConfigurableContentListBase,
// commerce
    CampaignItemListModel,
    MarketingUtils,
    templateString,
// resources
    resources
) {
    return declare([_ConfigurableContentListBase], {

        contextChangeEvent: "",

        templateString: templateString,

        storeKeyName: "epi.cms.content.light",

        typeIdentifiers: [
            MarketingUtils.contentTypeIdentifier.salesCampaign,
            MarketingUtils.contentTypeIdentifier.promotionData
        ],

        withDeleteButton : false,

        buildRendering: function () {
            // summary:
            //		Construct the UI for this widget with this.domNode initialized as a dgrid.
            // tags:
            //		protected

            this.inherited(arguments);

            this._modifyStoreToHandleDgridTree();
        },

        startup: function() {
            this.inherited(arguments);

            when(this.getCurrentContext()).then(lang.hitch(this, function (currentContext) {
                this.grid.set("query", this._getQuery(currentContext.id));
            }));
        },

        createModel: function () {
            return new CampaignItemListModel({
                store: this.store
            });
        },

        getListSettings: function() {
            var settings = this.inherited(arguments);
            if (this.withDeleteButton){
                this._replaceContextMenuByDeleteButton(settings.columns);
            }

            var self = this;
            return lang.mixin(this.defaultGridMixin, lang.mixin(settings, {
                className: "epi-card-grid",
                store: this.store,
                selectionMode: "none",
                cellNavigation: false,
                dndDisabled: true,
                showHeader: false,
                noDataMessage: resources.emptycampaign,
                renderArray: function(){
                    return when(this.inherited(arguments), lang.hitch(this, function(trs){
                        //After calling the inherited renderArray function we clear the noDataNode.
                        //This forces the grid to create a new node every time a campaign does not have any promotion.
                        this.noDataNode = null;
                        return trs;
                    }));
                },
                onContextMenuClick: function(e){
                    this.inherited(arguments);
                    self.onContextMenuClick(e);
                }
            }));
        },

        getColumnSettings: function(){
            return this.model.createGridColumns();
        },

        setupEvents: function(){
            this.inherited(arguments);
            for (var columnName in this.getColumnSettings()) {
                this.own(this.grid.on(".dgrid-cell.dgrid-column-" + columnName + ":dblclick", lang.hitch(this, "_onChangeContext")));
            }
            this.grid.addKeyHandler(keys.ENTER, lang.hitch(this, "_onChangeContext"));
            this.grid.addKeyHandler(keys.SPACE, lang.hitch(this, "_onChangeContext"));
            this.grid.addKeyHandler(keys.DELETE, lang.hitch(this, function(e){
                var row = this.grid.row(e);
                var deleteCommand = this.model.createDeleteCommand();
                deleteCommand.set("model", row.data);
                deleteCommand.execute();
            }));
            this.own(aspect.around(this.grid, "renderRow", lang.hitch(this, this._aroundRenderRow)));
        },

        _getQuery: function (parentId) {
            return {
                query: "getchildren",
                referenceId: parentId,
                typeIdentifiers: this.typeIdentifiers
            };
        },

        _aroundRenderRow: function (original) {
            // summary:
            //      Called 'around' the renderRow method in order to add a class which indicates the state of the row
            // tags:
            //      private

            return lang.hitch(this, function (item) {
                // Call original method
                var row = original.apply(this.grid, arguments);

                domClass.add(row, this.model.getItemClass(item));
                domClass.add(row, this.model.getItemStatusClass(item));

                return row;
            });
        },

        _modifyStoreToHandleDgridTree: function(){
            // summary:
            //      getChildren and mayHaveChildren are needed on the store
            //      for dgrids tree module to work.
            // tags:
            //      private
            var self = this;
            this.store = lang.mixin(this.store, {
                getChildren: function (parent, options) {
                    return this.query(self._getQuery(parent.contentLink), options);
                },
                mayHaveChildren: function (parent) {
                    // only campaigns have children
                    return TypeDescriptorManager.isBaseTypeIdentifier(parent.typeIdentifier, MarketingUtils.contentTypeIdentifier.salesCampaign);
                }
            });
        },

        onContextChanged: function(context){
            // Refresh list after edit
            this.grid.refresh();
        },

        onContextMenuClick: function(e) {
            this.inherited(arguments);
            var row = this.grid.row(e);
            this.model.updateCommandModel(row.data);
        },

        _replaceContextMenuByDeleteButton: function(columnSettings){
            columnSettings = lang.mixin(columnSettings, {
                contextMenu : {
                    renderHeaderCell: function () { }, // no header
                    renderCell: lang.hitch(this, function (object, value, node, options) {
                        var deleteCommand = this.model.createDeleteCommand(false);
                        var builder = new ButtonBuilder({
                            settings: {
                                showLabel: false,
                                "class": "epi-chromeless",
                                onKeyDown: function(e){
                                    if (e.keyCode === keys.ENTER){
                                        //when pressing ENTER on button
                                        //we need to stop the grids key
                                        //handler changing context.
                                        event.stop(e);
                                    }
                                }
                            }
                        });
                        deleteCommand.set("model", object);
                        builder.create(deleteCommand, node);
                    }),
                    className: "epi-columnNarrow",
                    sortable: false
                }
            });
        }
    });
});