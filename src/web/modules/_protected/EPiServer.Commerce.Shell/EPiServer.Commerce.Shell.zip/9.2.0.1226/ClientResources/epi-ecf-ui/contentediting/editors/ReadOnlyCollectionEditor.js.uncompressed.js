﻿define("epi-ecf-ui/contentediting/editors/ReadOnlyCollectionEditor", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-class",
    "dojo/topic",

    // dgrid
    "dgrid/Keyboard",
    "dgrid/OnDemandGrid",
    "dgrid/Selection",
    "dgrid/extensions/ColumnResizer",
    "dgrid/extensions/ColumnReorder",

    // dijit
    "dijit/form/Button",

    // EPi Framework
    "epi/shell/dgrid/Formatter",

    // epi cms
    "epi-cms/contentediting/editors/CollectionEditor",
    "epi-cms/dgrid/DnD",
    "epi-cms/dgrid/WithContextMenu",

    // commerce
     "../../dgrid/_ClickablePathColumnMixin",
     "./_GridWithDropContainerMixin"
],
function (
    //dojo
    declare,
    lang,
    domClass,
    topic,

    // dgrid
    Keyboard,
    OnDemandGrid,
    Selection,
    ColumnResizer,
    ColumnReorder,

    // dijit
    Button,

    // EPi Framework
    Formatter,

    // epi cms
    CollectionEditor,
    DnD,
    WithContextMenu,

    // commerce
     _ClickablePathColumnMixin,
     _GridWithDropContainerMixin
) {
    return declare([CollectionEditor, _GridWithDropContainerMixin], {
        // module:
        //      epi-ecf-ui/contentediting/editors/ReadOnlyCollectionEditor
        // summary:
        //      Represents the Read-only editor widget for product's price list.

        changeToView: null,

        buttonLabel: null,

        buttonClass: "epi-chromelessButton epi-visibleLink",

        iconClass: null,

        isLanguageSpecific: false,

        //isInMasterLanguage: Boolean
        //      Represents if the current content link is in master language or not
        isInMasterLanguage: false,

        isLinkButtonCreated: false,

        gridType: declare([OnDemandGrid, Formatter, Selection, Keyboard, DnD, ColumnResizer, ColumnReorder, WithContextMenu, _ClickablePathColumnMixin]),

        modelBindingMap: {
            "isInMasterLanguage": ["isInMasterLanguage"]
        },

        _setupGrid: function () {
            this.inherited(arguments);
            this.grid.set("selectionMode", "none");
        },

        _getGridDefinition: function () {
            // summary:
            //      Returns grid's columns definition.
            // tags:
            //      protected

            var columns = this.inherited(arguments);
            var typeColumn = columns.contentTypeIdentifier;
            if (typeColumn) {
                typeColumn.className = "epi-columnIcon16x16";
                typeColumn.label = "";
            }
            return columns;
        },

        postCreate: function () {
            this.inherited(arguments);
        },

        _setIsInMasterLanguageAttr: function (value) {
            // summary:
            //      IsInMasterLanguage setter.
            // description:
            //      Push value to the model to be its data.
            //  tags:
            //      private

            this._set("isInMasterLanguage", value);

            if (this.editable !== false && this.buttonLabel && !this.get("isLinkButtonCreated") && (this.isLanguageSpecific || value)) {
                // Add button only when button is assigned and the editor is editable.
                this.createButton();
            }
        },

        createButton: function () {
            var myButt = new Button({
                label: this.buttonLabel,
                iconClass: this.iconClass,
                "class": this.buttonClass,
                onClick: lang.hitch(this, function () {
                    topic.publish("/epi/shell/action/changeview", this.changeToView, {}, {});
                })
            });

            this.set("isLinkButtonCreated", true);

            this.own(myButt);
            this.domNode.appendChild(myButt.domNode);
        }
    });
});